"""Keep this entry point: python test.py opens the dashboard; --check runs tests."""
import sys

if __name__ == "__main__":
    if "--check" in sys.argv:
        import pytest
        raise SystemExit(pytest.main(["tests", "-q"]))
    from swarm_sim.main import main
    main()
