# Validation

Build checked on 31 October 2026. All results below were actually executed in the build environment. They are regression/integration evidence for this reduced simulator, not flight qualification or statistical evidence of algorithm superiority.

## Result

- **48 Python tests passed**, zero failures, errors or skipped tests; 6.38 s for the recorded run.
- **9 deterministic scenarios passed**, with 940 tick-level independent accounting checks.
- **13 browser checks passed** on Chromium 145.0.7632.6, with no JavaScript errors.
- Python compilation and JavaScript syntax checks passed.

The numerical suite includes analytic ADMM solutions and three seeded QPs compared against independent SciPy SLSQP solutions (objective error below 0.0002). Dynamic node-size tests cover 3, 6, 20 and 40 satellites.

## Scenarios

| Case | Nodes | Ticks | Delivered | Missed | Reassignments | Repaired routes |
|---|---:|---:|---:|---:|---:|---:|
| nominal_6 | 6 | 80 | 4 | 0 | 0 | 0 |
| dynamic_faults_6 | 6 | 300 | 42 | 0 | 2 | 2 |
| nominal_20 | 20 | 80 | 4 | 0 | 0 | 0 |
| dynamic_faults_20 | 20 | 300 | 42 | 0 | 1 | 0 |
| relay_link_loss | 6 | 70 | 1 | 0 | 0 | 1 |
| failed_holder_recovery | 6 | 70 | 1 | 0 | 0 | 0 |
| cpu_to_thermal_failure | 6 | 25 | 0 | 0 | 0 | 0 |
| residual_cusum | 6 | 5 | 0 | 0 | 0 | 0 |
| no_feasible_hosts | 6 | 10 | 0 | 1 | 0 | 0 |

The `no_feasible_hosts` scenario deliberately isolates all nodes; the expected outcome is a recorded missed task without an unsafe execution. Thermal and CUSUM cases contain no sensing jobs: their objective is detector behavior. In the dynamic cases, automatic arrivals stop after tick 240 and the remaining simulation drains the queue. All 42 generated products are delivered in both the 6-node and 20-node dynamic runs. These are deterministic scenarios, not an arrival-rate capacity estimate.

The failed-holder scenario checks that acquired data stays on the failed node, then delivers after that same node recovers. The relay scenario requires an existing product to reroute without a second acquisition.

## Browser checks

1. Dashboard and six-node mesh load.
2. Step button advances exactly one tick.
3. Run and pause control the live loop.
4. Sidebar fault excludes node and triggers repair.
5. Sidebar recovery returns the same node.
6. Task creation, ledger and escaped region text.
7. Task status filtering.
8. Solver panel and connection-weight CSV download.
9. Sidebar reset and live 20-node mesh.
10. Telemetry cards select matching sidebar node.
11. Events and guide render.
12. Mobile controls and no horizontal page overflow.
13. No browser JavaScript errors.

The browser test starts the real Python launcher/API, uses sidebar controls, receives live WebSocket snapshots, downloads CSV output, and inspects both desktop and 390-pixel mobile layouts. Screenshots were inspected after rendering.

## Files

- `pytest.xml`: machine-readable Python test results.
- `pytest_run.txt`: test run output.
- `scenarios.json`: scenario metrics, per-plan residuals and runtime, and fault/recovery events.
- `scenario_run.txt`: concise scenario output.
- `browser_results.json` and `browser_run.txt`: browser checks.
- `server_run.txt`: local server output captured during browser checks.
- `dashboard.png`, `dashboard20.png`, `fault_repair.png`, `solver.png`, `mobile.png`: screenshots.
- `connection_weights.csv`: actual dashboard download.

## Reproduce

From the extracted project directory:

```bash
python -m pip install -r requirements.txt
python test.py --check
python run_scenarios.py
python -m compileall -q swarm_sim tests test.py run_scenarios.py
```

Optional browser verification requires Node.js and Playwright; it is not needed to launch the simulator:

```bash
npm install --no-save playwright
npx playwright install chromium
node tests/browser_smoke.cjs
```

The script starts/stops its own server on port 8123. Set `SWARM_PYTHON` if your Python executable has another name. An existing compatible Chromium executable can be selected with `SWARM_BROWSER_PATH`. During this build, Chrome for Testing was used because the default browser mirror returned an invalid download.

## Environment

Python 3.12.14 on Linux.

| Package | Tested version |
|---|---|
| numpy | 2.3.5 |
| fastapi | 0.162.0 |
| pydantic | 2.14.1 |
| uvicorn | 0.54.0 |
| pytest | 9.2.0 |
| httpx | 0.28.1 |
| scipy | 1.17.0 |

The Python test runner emits one upstream Starlette/httpx deprecation warning. It does not affect the passing HTTP or WebSocket checks. Requirements specify compatible ranges; the versions above identify the actual build environment. Wall-clock solver times depend on CPU and system load.
